console.log("Start from server");


//~ function m_play(){
	//~ var id = l_get_id();
//~ console.log("Start");
	
	
//~ }


/**
 * Выдаст id
 * */
/*
function l_get_id(){
	var ss = Date.now()/1000 | 0;
	//~ console.log(typeof(ss));
	//~ console.log("ss=" + ss);
	//~ ?? чисоа не совпадают ??
	var t = ss/10008;
	//~ console.log(t);
	var t = t | 0;
	//~ console.log(t);
	t = (ss /10008 - t) * 10000 | 0;
	console.log(t);
	return t;
}
*/
